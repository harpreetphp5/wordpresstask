const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;
registerBlockType('customblock/firstblock', {

  title: __("Top Header", "customblock"),
  description: __("top header with text & button", "customblock"),
  category: "media",
  icon: {
    background: '#ff9900',
    foreground: '#fff',
    src: 'admin-network'
  },
  keywords: [ __('gallery','customblock'), __('news','customblock') ],
  edit: ({className}) => {
    return <div>
<div style="margin-bottom:10px;margin-top:10px;">
    <span>CORPORATE NEWS SUBSCRIPTION</span><span style="float:right;"><b>THE AUSTRALIAN</b><sup style="color:red;font-weight:bold;">*</sup></span>
</div>
<div style="text-align:center;height:310px;padding-top:150px;
    background: url('https://birobit.com/challenge/WPSite/wp-content/uploads/2020/11/header_image.png') no-repeat; background-position: center;background-size: cover;">
    <h1>The future of your business <br>relies on being informed.</h1>
    <a href="#myformWrap" class="btn btn-primary" style="background: #00405C; color: #fff; text-decoration: none; padding:15px;">Request a quote</a>
</div>
</div>;
  },
  save: ()=> {
    return <div>
<div style="margin-bottom:10px;margin-top:10px;">
    <span>CORPORATE NEWS SUBSCRIPTION</span><span style="float:right;"><b>THE AUSTRALIAN</b><sup style="color:red;font-weight:bold;">*</sup></span>
</div>
<div style="text-align:center;height:310px;padding-top:150px;
    background: url('https://birobit.com/challenge/WPSite/wp-content/uploads/2020/11/header_image.png') no-repeat; background-position: center;background-size: cover;">
    <h1>The future of your business <br>relies on being informed.</h1>
    <a href="#myformWrap" class="btn btn-primary" style="background: #00405C; color: #fff; text-decoration: none; padding:15px;">Request a quote</a>
</div>
</div>
  }

});